#
#                                                         
# These Python scripts are for educational purposes only! 
#                                                         
fuzzer.py - this script sends data to SLmail, starting at 100, increasing by 200 until 4000 is reached or until SLmail crashes. The purpose is to find the point at which SLmail crashes relative to the data that's being sent.

poc.py - this script is used to find the position of the EIP.

poc2.py - this script is used to test if the EIP can be reliably controlled.

poc3.py/poc4.py/poc5.py - these scripts are to test for bad characters.

slmailsploit.py - this script is used to exploit SLmail to acquire a SYSTEM level reverse shell.
#
#                                                                               
# Please check out my Udemy courses! Coupon code applied to following links.... 
#                                                                               
Kali Linux Hands-on Penetration Testing Labs:

https://www.udemy.com/kali-linux-hands-on-penetration-testing-labs/?couponCode=TENDOLLARS


Network Security Analysis Using Wireshark, Snort, and SO:

https://www.udemy.com/network-security-analysis-using-wireshark-snort-and-so/?couponCode=TENDOLLARS


Snort Intrusion Detection, Rule Writing, and PCAP Analysis:

https://www.udemy.com/snort-intrusion-detection-rule-writing-and-pcap-analysis/?couponCode=TENDOLLARS

