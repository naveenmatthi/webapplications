mona
====

Corelan Repository for mona.py


Installation instructions
-------------------------

### Immunity Debugger
1. drop mona.py into the 'PyCommands' folder (inside the Immunity Debugger application folder).
2. install Python 2.7.14 (or a higher 2.7.xx version) into c:\python27, thus overwriting the version that was bundled with Immunity. This is needed to avoid TLS issues when trying to update mona.

### WinDBG
See https://github.com/corelan/windbglib
